using KidHub.Data.Entities;
using KidHub.Data.Repositories.CourseRepo;
using KidHub.Domain.Services.PaymentService;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace KidHub.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PaymentController : ControllerBase
    {
        private readonly IPaymobService _paymobService;
        private readonly ICourseRepository _courseRepository;
        private readonly UserManager<ApplicationUser> _userManager;

        public PaymentController(
            IPaymobService paymobService,
            ICourseRepository courseRepository,
            UserManager<ApplicationUser> userManager)
        {
            _paymobService = paymobService;
            _courseRepository = courseRepository;
            _userManager = userManager;
        }

        [HttpPost("initiate")]
        [Authorize]
        public async Task<IActionResult> InitiatePayment([FromBody] InitiatePaymentRequest request)
        {
            try
            {
                // Get the course
                var course = await _courseRepository.GetAsync(request.CourseId);
                if (course == null)
                    return NotFound("Course not found");

                // Get the current user
                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                var user = await _userManager.FindByIdAsync(userId);
                if (user == null)
                    return Unauthorized();

                // Get authentication token
                var authToken = await _paymobService.GetAuthenticationTokenAsync();

                // Create order
                var order = await _paymobService.CreateOrderAsync(authToken, course.Price ?? 0, course.Title);

                // Get payment key
                var paymentKey = await _paymobService.GetPaymentKeyAsync(
                    authToken,
                    order.Id,
                    user.Email,
                    user.UserName,
                    user.UserName,
                    user.PhoneNumber ?? "NA"
                );

                // Create payment record
                var payment = new Payment
                {
                    UserId = userId,
                    CourseId = course.Id,
                    Amount = course.Price ?? 0,
                    Currency = "EGP",
                    PaymentStatus = "Pending",
                    PaymobOrderId = order.Id.ToString(),
                    CreatedAt = DateTime.UtcNow
                };

                // Save payment record
                await _courseRepository.AddPaymentAsync(payment);
                await _courseRepository.SaveAsync();

                // Return payment URL
                return Ok(new
                {
                    PaymentUrl = $"https://accept.paymob.com/api/acceptance/iframes/{_config.IframeId}?payment_token={paymentKey}"
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred: {ex.Message}");
            }
        }

        [HttpPost("callback")]
        public async Task<IActionResult> PaymentCallback([FromBody] PaymobCallbackRequest request)
        {
            try
            {
                // Validate HMAC
                var isValid = await _paymobService.ValidateHmacAsync(request.Hmac, request.Data);
                if (!isValid)
                    return BadRequest("Invalid HMAC");

                // Get transaction details
                var transaction = await _paymobService.GetTransactionDetailsAsync(request.TransactionId);
                if (!transaction.Success)
                    return BadRequest("Transaction failed");

                // Update payment record
                var payment = await _courseRepository.GetPaymentByOrderIdAsync(request.OrderId.ToString());
                if (payment == null)
                    return NotFound("Payment record not found");

                payment.PaymentStatus = "Completed";
                payment.PaymobTransactionId = request.TransactionId.ToString();
                payment.CompletedAt = DateTime.UtcNow;

                // Create user course enrollment
                var userCourse = new UserCourse
                {
                    UserId = payment.UserId,
                    CourseId = payment.CourseId,
                    EnrolledOn = DateTime.UtcNow,
                    IsCompleted = false
                };

                await _courseRepository.AddUserCourseAsync(userCourse);
                await _courseRepository.SaveAsync();

                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred: {ex.Message}");
            }
        }
    }

    public class InitiatePaymentRequest
    {
        public Guid CourseId { get; set; }
    }

    public class PaymobCallbackRequest
    {
        public string Hmac { get; set; }
        public string Data { get; set; }
        public int TransactionId { get; set; }
        public int OrderId { get; set; }
    }
} 