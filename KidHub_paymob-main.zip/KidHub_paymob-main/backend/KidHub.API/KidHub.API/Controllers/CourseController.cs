﻿using KidHub.Domain.Dtos.CourseDtos;
using KidHub.Domain.Services.CourseService;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using KidHub.Data.Entities;
using KidHub.Service;

namespace KidHub.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CourseController : ControllerBase
    {
        private readonly ICourseService _courseService;

        public CourseController(ICourseService courseService)
        {
            _courseService = courseService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var courses = await _courseService.GetAllCoursesAsync();
            return Ok(courses);
        }

        [HttpGet("{id}")]
        [Authorize]
        public async Task<ActionResult<Course>> GetCourse(Guid id)
        {
            var userId = User.FindFirst("sub")?.Value;
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized();
            }

            try
            {
                var course = await _courseService.GetCourseWithAccessCheckAsync(userId, id);
                if (course == null)
                {
                    return NotFound();
                }

                return Ok(course);
            }
            catch (UnauthorizedAccessException)
            {
                return Forbid();
            }
        }

        [HttpPost]
        //[Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create([FromBody] CreateCourseDto dto)
        {
            var created = await _courseService.CreateCourseAsync(dto);
            return CreatedAtAction(nameof(GetCourse), new { id = created.Id }, created);
        }
    }
}