namespace KidHub.Domain.Configuration
{
    public class PaymobConfig
    {
        public string ApiKey { get; set; }
        public string IntegrationId { get; set; }
        public string IframeId { get; set; }
        public string HmacSecret { get; set; }
        public string BaseUrl { get; set; } = "https://accept.paymob.com/api";
    }
} 