﻿using AutoMapper;
using KidHub.Data.Repositories.CourseRepo;
using KidHub.Data.Entities;
using KidHub.Domain.Dtos.CourseDtos;

namespace KidHub.Domain.Services.CourseService;

public class CourseService : ICourseService
{
    private readonly ICourseRepository _courseRepository;
    private readonly IMapper _mapper;

    public CourseService(ICourseRepository courseRepository, IMapper mapper)
    {
        _courseRepository = courseRepository;
        _mapper = mapper;
    }

    public async Task<IEnumerable<CourseDto>> GetAllCoursesAsync()
    {
        var courses = await _courseRepository.GetAllAsync();
        return _mapper.Map<IEnumerable<CourseDto>>(courses);
    }

    public async Task<CourseDto> GetCourseByIdAsync(Guid id)
    {
        var course = await _courseRepository.GetAsync(id);
        return _mapper.Map<CourseDto>(course);
    }

    public async Task<CourseDto> CreateCourseAsync(CreateCourseDto dto)
    {
        var course = _mapper.Map<Course>(dto);
        await _courseRepository.AddAsync(course);
        await _courseRepository.SaveAsync();
        return _mapper.Map<CourseDto>(course);
    }

    public async Task<bool> HasUserAccessToCourseAsync(string userId, Guid courseId)
    {
        // Get the course
        var course = await _courseRepository.GetAsync(courseId);
        if (course == null)
            return false;

        // If the course is free, allow access
        if (!course.IsPremiumOnly.HasValue || !course.IsPremiumOnly.Value || course.Price == 0)
            return true;

        // Check if user has a completed payment for this course
        var hasPayment = await _courseRepository.HasValidPaymentAsync(userId, courseId);
        if (hasPayment)
            return true;

        // Check if user is enrolled in the course
        var isEnrolled = await _courseRepository.IsUserEnrolledAsync(userId, courseId);
        return isEnrolled;
    }
}
