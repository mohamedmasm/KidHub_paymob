using KidHub.Domain.Dtos.PaymentDtos;

namespace KidHub.Domain.Services.PaymentService
{
    public interface IPaymobService
    {
        Task<string> GetAuthenticationTokenAsync();
        Task<PaymobOrderResponse> CreateOrderAsync(string authToken, decimal amount, string courseTitle);
        Task<string> GetPaymentKeyAsync(string authToken, int orderId, string userEmail, string firstName, string lastName, string phoneNumber);
        Task<PaymobTransactionResponse> GetTransactionDetailsAsync(int transactionId);
        Task<bool> ValidateHmacAsync(string hmac, string data);
    }
} 