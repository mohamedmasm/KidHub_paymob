using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using KidHub.Domain.Configuration;
using KidHub.Domain.Dtos.PaymentDtos;
using Microsoft.Extensions.Options;

namespace KidHub.Domain.Services.PaymentService
{
    public class PaymobService : IPaymobService
    {
        private readonly HttpClient _httpClient;
        private readonly PaymobConfig _config;

        public PaymobService(HttpClient httpClient, IOptions<PaymobConfig> config)
        {
            _httpClient = httpClient;
            _config = config.Value;
            _httpClient.BaseAddress = new Uri(_config.BaseUrl);
        }

        public async Task<string> GetAuthenticationTokenAsync()
        {
            var request = new PaymobAuthenticationRequest
            {
                ApiKey = _config.ApiKey
            };

            var response = await _httpClient.PostAsJsonAsync("/auth/tokens", request);
            response.EnsureSuccessStatusCode();

            var result = await response.Content.ReadFromJsonAsync<PaymobAuthenticationResponse>();
            return result.Token;
        }

        public async Task<PaymobOrderResponse> CreateOrderAsync(string authToken, decimal amount, string courseTitle)
        {
            var request = new PaymobOrderRequest
            {
                AuthToken = authToken,
                AmountCents = (int)(amount * 100), // Convert to cents
                Currency = "EGP",
                Items = new List<PaymobOrderItem>
                {
                    new PaymobOrderItem
                    {
                        Name = courseTitle,
                        AmountCents = (int)(amount * 100),
                        Description = $"Payment for course: {courseTitle}",
                        Quantity = 1
                    }
                }
            };

            var response = await _httpClient.PostAsJsonAsync("/ecommerce/orders", request);
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadFromJsonAsync<PaymobOrderResponse>();
        }

        public async Task<string> GetPaymentKeyAsync(string authToken, int orderId, string userEmail, string firstName, string lastName, string phoneNumber)
        {
            var request = new PaymobPaymentKeyRequest
            {
                AuthToken = authToken,
                AmountCents = 0, // Will be set from the order
                Expiration = 3600,
                OrderId = orderId,
                BillingData = new PaymobBillingData
                {
                    Email = userEmail,
                    FirstName = firstName,
                    LastName = lastName,
                    PhoneNumber = phoneNumber
                },
                Currency = "EGP",
                IntegrationId = int.Parse(_config.IntegrationId)
            };

            var response = await _httpClient.PostAsJsonAsync("/acceptance/payment_keys", request);
            response.EnsureSuccessStatusCode();

            var result = await response.Content.ReadFromJsonAsync<PaymobPaymentKeyResponse>();
            return result.Token;
        }

        public async Task<PaymobTransactionResponse> GetTransactionDetailsAsync(int transactionId)
        {
            var response = await _httpClient.GetAsync($"/acceptance/transactions/{transactionId}");
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadFromJsonAsync<PaymobTransactionResponse>();
        }

        public async Task<bool> ValidateHmacAsync(string hmac, string data)
        {
            using var hmacsha512 = new HMACSHA512(Encoding.UTF8.GetBytes(_config.HmacSecret));
            var hash = hmacsha512.ComputeHash(Encoding.UTF8.GetBytes(data));
            var calculatedHmac = BitConverter.ToString(hash).Replace("-", "").ToLower();

            return calculatedHmac == hmac.ToLower();
        }
    }
} 