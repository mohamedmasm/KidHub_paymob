using KidHub.Data.Entities;

namespace KidHub.Service
{
    public interface ICourseService
    {
        Task<bool> CanUserAccessCourseAsync(string userId, Guid courseId);
        Task<Course> GetCourseWithAccessCheckAsync(string userId, Guid courseId);
        // ... existing code ...
    }
} 