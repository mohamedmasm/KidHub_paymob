using KidHub.Data.Entities;
using KidHub.Data.Repositories.CourseRepo;
using KidHub.Data.Repositories.MainRepo;
using Microsoft.EntityFrameworkCore;

namespace KidHub.Service
{
    public class CourseService : ICourseService
    {
        private readonly ICourseRepository _courseRepository;
        private readonly IRepository<Payment, Guid> _paymentRepository;
        private readonly IRepository<UserCourse, Guid> _userCourseRepository;

        public CourseService(
            ICourseRepository courseRepository,
            IRepository<Payment, Guid> paymentRepository,
            IRepository<UserCourse, Guid> userCourseRepository)
        {
            _courseRepository = courseRepository;
            _paymentRepository = paymentRepository;
            _userCourseRepository = userCourseRepository;
        }

        public async Task<bool> CanUserAccessCourseAsync(string userId, Guid courseId)
        {
            var course = await _courseRepository.GetByIdAsync(courseId);
            if (course == null) return false;

            // If course is free, user can access it
            if (!course.IsPaid) return true;

            // Check if user has a valid payment
            var hasValidPayment = await _courseRepository.HasValidPaymentAsync(userId, courseId);
            if (hasValidPayment) return true;

            // Check if user is enrolled
            return await _courseRepository.IsUserEnrolledAsync(userId, courseId);
        }

        public async Task<Course> GetCourseWithAccessCheckAsync(string userId, Guid courseId)
        {
            var course = await _courseRepository.GetByIdAsync(courseId);
            if (course == null) return null;

            if (!await CanUserAccessCourseAsync(userId, courseId))
            {
                throw new UnauthorizedAccessException("You don't have access to this course");
            }

            return course;
        }

        // ... existing code ...
    }
} 