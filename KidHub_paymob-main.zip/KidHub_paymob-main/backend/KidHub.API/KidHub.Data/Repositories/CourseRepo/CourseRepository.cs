﻿using KidHub.Data.Data;
using KidHub.Data.Entities;
using KidHub.Data.Repositories.MainRepo;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KidHub.Data.Repositories.CourseRepo
{
    public class CourseRepository : Repository<Course, Guid>, ICourseRepository
    {
        private readonly ApplicationDbContext _context;

        public CourseRepository(ApplicationDbContext context) : base(context)
        {
            _context = context;
        }

        public async Task AddPaymentAsync(Payment payment)
        {
            await _context.Payments.AddAsync(payment);
        }

        public async Task AddUserCourseAsync(UserCourse userCourse)
        {
            await _context.UserCourses.AddAsync(userCourse);
        }

        public async Task<Payment> GetPaymentByOrderIdAsync(string orderId)
        {
            return await _context.Payments
                .FirstOrDefaultAsync(p => p.PaymobOrderId == orderId);
        }

        public async Task<bool> HasValidPaymentAsync(string userId, Guid courseId)
        {
            return await _context.Payments
                .AnyAsync(p => p.UserId == userId 
                    && p.CourseId == courseId 
                    && p.PaymentStatus == "Completed");
        }

        public async Task<bool> IsUserEnrolledAsync(string userId, Guid courseId)
        {
            return await _context.UserCourses
                .AnyAsync(uc => uc.UserId == userId && uc.CourseId == courseId);
        }

        // Only put course-specific methods here, like:

    }
}
