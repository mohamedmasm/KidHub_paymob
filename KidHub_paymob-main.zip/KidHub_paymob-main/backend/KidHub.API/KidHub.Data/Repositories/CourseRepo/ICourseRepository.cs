﻿using KidHub.Data.Entities;
using KidHub.Data.Repositories.MainRepo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KidHub.Data.Repositories.CourseRepo
{
    public interface ICourseRepository : IRepository<Course, Guid>
    {
        Task AddPaymentAsync(Payment payment);
        Task AddUserCourseAsync(UserCourse userCourse);
        Task<Payment> GetPaymentByOrderIdAsync(string orderId);
        Task<bool> HasValidPaymentAsync(string userId, Guid courseId);
        Task<bool> IsUserEnrolledAsync(string userId, Guid courseId);
    }
}
