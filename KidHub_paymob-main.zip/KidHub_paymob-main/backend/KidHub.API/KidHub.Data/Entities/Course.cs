﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KidHub.Data.Entities
{
     public class Course
    {
        public Guid Id { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }
        public string? Category { get; set; }
        public string? ThumbnailUrl { get; set; }
        public decimal? Price { get; set; } // Can be 0 for free courses
        public bool? IsPremiumOnly { get; set; }
        
        // New properties
        public Guid DepartmentId { get; set; }
        public Guid CourseLevelId { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public bool IsActive { get; set; } = true;
        public int? DurationInHours { get; set; }
        public string? Prerequisites { get; set; }

        // Navigation properties
        public Department Department { get; set; }
        public CourseLevel CourseLevel { get; set; }
        public ICollection<UserCourse>? EnrolledUsers { get; set; }
        public ICollection<Lesson> Lessons { get; set; } = new List<Lesson>();
        public ICollection<Payment> Payments { get; set; } = new List<Payment>();
    }

}
