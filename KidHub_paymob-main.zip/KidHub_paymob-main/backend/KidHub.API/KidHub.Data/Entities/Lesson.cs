﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KidHub.Data.Entities
{
    public class Lesson
    {
        public Guid Id { get; set; }
        public string? Title { get; set; }
        public string? ContentType { get; set; } // "video", "article", etc.
        public string? ContentUrl { get; set; } // link to video/file/text
        public Guid? CourseId { get; set; }
        public Course? Course { get; set; }
        
        // New properties
        public int Order { get; set; } // For ordering lessons within a course
        public string? Description { get; set; }
        public int? DurationInMinutes { get; set; }
        public bool IsActive { get; set; } = true;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        
        // Navigation properties
        public ICollection<LessonAttachment> Attachments { get; set; } = new List<LessonAttachment>();
    }
}
