using System;
using System.Collections.Generic;

namespace KidHub.Data.Entities
{
    public class CourseLevel
    {
        public Guid Id { get; set; }
        public string Name { get; set; } // e.g., "Beginner", "Intermediate", "Advanced"
        public string Description { get; set; }
        public int Order { get; set; } // For sorting/ordering levels
        public bool IsActive { get; set; } = true;
        
        // Navigation properties
        public ICollection<Course> Courses { get; set; } = new List<Course>();
    }
} 