using System;

namespace KidHub.Data.Entities
{
    public class Payment
    {
        public Guid Id { get; set; }
        public string UserId { get; set; } // Foreign key to ApplicationUser
        public Guid CourseId { get; set; } // Foreign key to Course
        public decimal Amount { get; set; }
        public string Currency { get; set; } = "EGP";
        public string PaymentStatus { get; set; } // "Pending", "Completed", "Failed", "Refunded"
        public string? PaymobTransactionId { get; set; }
        public string? PaymobOrderId { get; set; }
        public string? PaymobPaymentKey { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime? CompletedAt { get; set; }
        public string? ErrorMessage { get; set; }
        
        // Navigation properties
        public ApplicationUser User { get; set; }
        public Course Course { get; set; }
    }
} 