using System;

namespace KidHub.Data.Entities
{
    public class LessonAttachment
    {
        public Guid Id { get; set; }
        public Guid LessonId { get; set; }
        public string FileName { get; set; }
        public string FileUrl { get; set; }
        public string FileType { get; set; } // e.g., "pdf", "doc", "zip"
        public long FileSize { get; set; } // in bytes
        public string? Description { get; set; }
        public bool IsDownloadable { get; set; } = true;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        
        // Navigation property
        public Lesson Lesson { get; set; }
    }
} 